## What is this?
Bare website skeleton written in Python Django for 'Introduction to Django' room on TryHackMe. 

## Version Data
Django version: 2.2

Python version: 3.7

## Flag you are looking for
Your flag: `THM{g1t_djang0_hUb}`
